﻿public partial class Enemy : CharacterBase {
	void Start() {
		SecondsToNextRoll(3);
	}

	void HandleAnimation(int animationHash) {
		// play anaimation
	}
}

