﻿using System;

[Serializable]
public class SettingsData { // settings information
	public bool soundEffects = false;
	public bool music = false;
}