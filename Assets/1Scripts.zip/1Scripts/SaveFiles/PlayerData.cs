﻿using System;

[Serializable]
public class PlayerData { // character information
	public int health = 100;
}