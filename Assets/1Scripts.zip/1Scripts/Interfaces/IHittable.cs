﻿public interface IHittable {
	void GettingHit(int damage);
	void Death();
}
