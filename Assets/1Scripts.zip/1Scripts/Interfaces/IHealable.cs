﻿public interface IHealable {
	void Heal(int health);
}
